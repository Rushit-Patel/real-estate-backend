<?php
return [
    'intract_url' => 'https://api.interakt.ai/v1/public',
    'intract_key' => 'N1J4b0F6aVIzamRDZUFWM2d5Z1N0UURyblVpMHZOazdLbmdrT2lEVWI1Yzo=',
];
